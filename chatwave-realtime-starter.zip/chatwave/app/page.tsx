"use client";

import { FormEvent, useCallback, useEffect, useRef, useState } from "react";
import { createClient } from "@/lib/supabase";

type Profile = { id: string; display_name: string | null };
type Conversation = {
  id: string;
  created_at: string;
  conversation_members: { user_id: string; profiles: Profile | null }[];
};
type Message = {
  id: string;
  conversation_id: string;
  sender_id: string;
  body: string;
  created_at: string;
};

const supabase = createClient();

function initials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map((s) => s[0]?.toUpperCase() || "").join("") || "CW";
}
function shortTime(value?: string) {
  if (!value) return "";
  return new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export default function Home() {
  const [session, setSession] = useState<any>(null);
  const [profileName, setProfileName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signup");
  const [authBusy, setAuthBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [search, setSearch] = useState("");
  const [showInfo, setShowInfo] = useState(false);
  const [mobileChat, setMobileChat] = useState(false);
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
      setNotice("");
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  const loadConversations = useCallback(async () => {
    if (!session?.user?.id) return;
    setLoading(true);
    const { data, error } = await supabase
      .from("conversation_members")
      .select("conversation_id, conversations(id, created_at, conversation_members(user_id, profiles(id, display_name)))")
      .eq("user_id", session.user.id);
    if (error) {
      setNotice("Could not load chats: " + error.message);
      setLoading(false);
      return;
    }
    const unique = new Map<string, Conversation>();
    (data || []).forEach((row: any) => {
      const c = Array.isArray(row.conversations) ? row.conversations[0] : row.conversations;
      if (c?.id) unique.set(c.id, c as Conversation);
    });
    const list = Array.from(unique.values()).sort((a, b) => b.created_at.localeCompare(a.created_at));
    setConversations(list);
    setActiveId((old) => old && list.some((c) => c.id === old) ? old : list[0]?.id || "");
    setLoading(false);
  }, [session?.user?.id]);

  useEffect(() => { if (session?.user?.id) loadConversations(); }, [session?.user?.id, loadConversations]);

  useEffect(() => {
    if (!session?.user?.id || !activeId) { setMessages([]); return; }
    let alive = true;
    async function loadMessages() {
      const { data, error } = await supabase.from("messages").select("*").eq("conversation_id", activeId).order("created_at", { ascending: true }).limit(500);
      if (!alive) return;
      if (error) setNotice("Could not load messages: " + error.message);
      else setMessages((data || []) as Message[]);
    }
    loadMessages();
    const channel = supabase.channel("messages-" + activeId)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: "conversation_id=eq." + activeId }, (payload) => {
        const incoming = payload.new as Message;
        setMessages((current) => current.some((m) => m.id === incoming.id) ? current : [...current, incoming]);
      }).subscribe();
    return () => { alive = false; supabase.removeChannel(channel); };
  }, [activeId, session?.user?.id]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  async function authenticate(e: FormEvent) {
    e.preventDefault(); setAuthBusy(true); setNotice("");
    try {
      if (authMode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { display_name: profileName.trim() || email.split("@")[0] } }
        });
        if (error) throw error;
        if (!data.session) setNotice("Account created. Check your email to confirm your address, then sign in.");
        else setNotice("Welcome to ChatWave!");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
      }
    } catch (err: any) { setNotice(err.message || "Authentication failed."); }
    finally { setAuthBusy(false); }
  }

  async function sendMessage(e: FormEvent) {
    e.preventDefault();
    const body = draft.trim();
    if (!body || !activeId || !session?.user?.id) return;
    setDraft("");
    const { error } = await supabase.from("messages").insert({
      conversation_id: activeId, sender_id: session.user.id, body
    });
    if (error) { setDraft(body); setNotice("Message not sent: " + error.message); }
  }

  async function startConversation(e: FormEvent) {
    e.preventDefault(); setNotice("");
    const target = newEmail.trim().toLowerCase();
    if (!target) return;
    const { data, error } = await supabase.rpc("start_conversation", { other_email: target });
    if (error) { setNotice(error.message); return; }
    setNewEmail(""); setShowNew(false);
    await loadConversations();
    if (data) { setActiveId(data as string); setMobileChat(true); }
  }

  async function signOut() {
    await supabase.auth.signOut();
    setConversations([]); setMessages([]); setActiveId("");
  }

  const current = conversations.find((c) => c.id === activeId);
  const others = current?.conversation_members?.filter((m) => m.user_id !== session?.user?.id) || [];
  const otherProfile = others[0]?.profiles;
  const currentName = otherProfile?.display_name || "New conversation";
  const filtered = conversations.filter((c) => {
    const names = c.conversation_members?.map((m) => m.profiles?.display_name || "").join(" ") || "";
    const content = messages.filter((m) => m.conversation_id === c.id).map((m) => m.body).join(" ");
    return (names + " " + content).toLowerCase().includes(search.toLowerCase());
  });

  if (!session) return (
    <main className="authPage">
      <section className="authCard">
        <div className="logoMark">●</div>
        <p className="eyebrow">YOUR PEOPLE, CLOSER</p>
        <h1>ChatWave</h1>
        <p className="muted intro">Simple, thoughtful messaging. Wherever life takes you.</p>
        <div className="authToggle">
          <button className={authMode === "signup" ? "selected" : ""} onClick={() => setAuthMode("signup")}>Create account</button>
          <button className={authMode === "signin" ? "selected" : ""} onClick={() => setAuthMode("signin")}>Sign in</button>
        </div>
        <form onSubmit={authenticate} className="authForm">
          {authMode === "signup" && <label>Your name<input value={profileName} onChange={(e) => setProfileName(e.target.value)} placeholder="How should people know you?" autoComplete="name" /></label>}
          <label>Email address<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" /></label>
          <label>Password<input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 8 characters" autoComplete={authMode === "signup" ? "new-password" : "current-password"} /></label>
          <button className="primary wide" disabled={authBusy}>{authBusy ? "Please wait…" : authMode === "signup" ? "Create your account →" : "Sign in →"}</button>
        </form>
        {notice && <p className="notice">{notice}</p>}
        <p className="finePrint">This starter uses Supabase authentication. Confirm your email if your project requires it.</p>
      </section>
    </main>
  );

  return (
    <main className="appPage">
      <section className="appShell">
        <header className="topbar">
          <div className="brand"><div className="miniLogo">●</div><div><strong>ChatWave</strong><span>Messages that feel closer.</span></div></div>
          <div className="topActions"><span className="secureTag"><i /> Private workspace</span><button className="avatar me" title="Sign out" onClick={signOut}>{initials(session.user.user_metadata?.display_name || session.user.email || "Me")}</button></div>
        </header>
        <div className={"messenger " + (mobileChat ? "mobileChat" : "")}>
          <aside className="sidebar">
            <div className="sideTitle"><h2>Messages</h2><button className="roundButton" onClick={() => setShowNew(true)} title="New conversation">＋</button></div>
            <div className="search"><span>⌕</span><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search conversations" /></div>
            <div className="label">RECENT</div>
            <div className="conversationList">
              {loading && <p className="empty">Loading conversations…</p>}
              {!loading && filtered.map((c) => {
                const other = c.conversation_members?.find((m) => m.user_id !== session.user.id)?.profiles;
                const name = other?.display_name || "ChatWave member";
                const last = messages.filter((m) => m.conversation_id === c.id).slice(-1)[0];
                return <button key={c.id} className={"conversation " + (c.id === activeId ? "active" : "")} onClick={() => { setActiveId(c.id); setMobileChat(true); }}>
                  <div className="avatar" style={{ background: colorFor(name) }}>{initials(name)}</div>
                  <div className="convText"><div className="convLine"><strong>{name}</strong><time>{shortTime(last?.created_at || c.created_at)}</time></div><p>{last ? (last.sender_id === session.user.id ? "You: " : "") + last.body : "Start a conversation"}</p></div>
                </button>;
              })}
              {!loading && filtered.length === 0 && <div className="empty">{search ? "No matching chats." : "No conversations yet. Start one with ＋"}</div>}
            </div>
            <div className="sideBottom"><span className="onlineDot" /> Signed in as <b>{session.user.email}</b></div>
          </aside>
          <section className="chatPanel">
            {activeId ? <>
              <header className="chatHeader">
                <button className="backButton" onClick={() => setMobileChat(false)}>‹ Messages</button>
                <div className="personHeader"><div className="avatar small" style={{ background: colorFor(currentName) }}>{initials(currentName)}</div><div><strong>{currentName}</strong><span>ChatWave conversation</span></div></div>
                <button className="roundButton infoButton" onClick={() => setShowInfo(!showInfo)} title="Conversation details">ⓘ</button>
              </header>
              {showInfo && <div className="infoPanel"><b>{currentName}</b><span>Messages are delivered through your configured Supabase project. This starter does not implement end-to-end encryption.</span></div>}
              <div className="messages">
                <div className="dayPill">MESSAGES</div>
                {messages.map((m) => <div key={m.id} className={"messageRow " + (m.sender_id === session.user.id ? "mine" : "")}>
                  <div className={"bubble " + (m.sender_id === session.user.id ? "outgoing" : "incoming")}>{m.body}<time>{shortTime(m.created_at)}{m.sender_id === session.user.id ? " · Sent" : ""}</time></div>
                </div>)}
                {messages.length === 0 && <div className="empty chatEmpty">A new conversation, a fresh start.<br />Send the first message below.</div>}
                <div ref={bottomRef} />
              </div>
              <form className="composer" onSubmit={sendMessage}><button className="emojiButton" type="button" onClick={() => setDraft((v) => v + " 😊")} title="Add emoji">☺</button><input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Write a message…" maxLength={5000} aria-label="Message" /><button className="sendButton" disabled={!draft.trim()} aria-label="Send message">↑</button></form>
              <p className="composerNote">Messages are shared with conversation members. Be thoughtful with personal information.</p>
            </> : <div className="welcome"><div className="welcomeIcon">✳</div><h2>Your conversations start here.</h2><p>Start a chat with someone using their registered email address.</p><button className="primary" onClick={() => setShowNew(true)}>＋ New conversation</button></div>}
          </section>
        </div>
        {showNew && <div className="modalBackdrop" onClick={() => setShowNew(false)}><form className="modal" onSubmit={startConversation} onClick={(e) => e.stopPropagation()}><div className="modalIcon">✉</div><h3>New conversation</h3><p>Enter the email address another person used to register for ChatWave.</p><label>Email address<input autoFocus type="email" required value={newEmail} onChange={(e) => setNewEmail(e.target.value)} placeholder="friend@example.com" /></label><div className="modalActions"><button type="button" className="secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="primary">Start chat →</button></div></form></div>}
        {notice && <button className="toast" onClick={() => setNotice("")}>{notice} <span>×</span></button>}
      </section>
      <p className="pageFoot">ChatWave · Built for thoughtful conversations</p>
    </main>
  );
}

function colorFor(name: string) {
  const colors = ["#6699dc", "#a28bd2", "#d29b68", "#65a998", "#8195c4", "#d27e98"];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) | 0;
  return colors[Math.abs(hash) % colors.length];
}
