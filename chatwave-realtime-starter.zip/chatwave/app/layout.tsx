import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ChatWave — Messages that feel closer",
  description: "A real-time messaging app starter built with Next.js and Supabase."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
