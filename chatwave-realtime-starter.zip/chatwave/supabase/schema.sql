-- ChatWave schema for Supabase.
-- Run in Supabase SQL Editor. Review before deploying to production.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'ChatWave member',
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 5000),
  created_at timestamptz not null default now()
);

create index if not exists messages_conversation_created_idx
  on public.messages (conversation_id, created_at);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''), split_part(new.email, '@', 1), 'ChatWave member')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_chatwave on auth.users;
create trigger on_auth_user_created_chatwave
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

drop policy if exists "Authenticated users can view basic profiles" on public.profiles;
create policy "Authenticated users can view basic profiles"
on public.profiles for select to authenticated
using (true);

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
on public.profiles for update to authenticated
using (id = (select auth.uid()))
with check (id = (select auth.uid()));

-- SECURITY DEFINER membership helper avoids recursive RLS when a policy
-- needs to inspect conversation_members itself.
create or replace function public.is_conversation_member(target_conversation uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = target_conversation
      and cm.user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_conversation_member(uuid) from public;
grant execute on function public.is_conversation_member(uuid) to authenticated;

drop policy if exists "Members can view conversations" on public.conversations;
create policy "Members can view conversations"
on public.conversations for select to authenticated
using (public.is_conversation_member(id));

drop policy if exists "Members can view membership" on public.conversation_members;
create policy "Members can view membership"
on public.conversation_members for select to authenticated
using (public.is_conversation_member(conversation_id));

drop policy if exists "Members can read messages" on public.messages;
create policy "Members can read messages"
on public.messages for select to authenticated
using (public.is_conversation_member(conversation_id));

drop policy if exists "Members can send as themselves" on public.messages;
create policy "Members can send as themselves"
on public.messages for insert to authenticated
with check (
  sender_id = (select auth.uid())
  and public.is_conversation_member(conversation_id)
);

-- Only authenticated callers can create a direct conversation with a registered email.
-- Email is looked up inside auth.users; it is not exposed through public profiles.
create or replace function public.start_conversation(other_email text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  caller uuid := auth.uid();
  other_user uuid;
  new_conversation uuid;
  existing_conversation uuid;
begin
  if caller is null then
    raise exception 'You must sign in first.';
  end if;
  if other_email is null or length(trim(other_email)) < 3 then
    raise exception 'Enter a valid email address.';
  end if;

  select u.id into other_user
  from auth.users u
  where lower(u.email) = lower(trim(other_email))
  limit 1;

  if other_user is null then
    raise exception 'No registered user found for that email.';
  end if;
  if other_user = caller then
    raise exception 'You cannot start a conversation with yourself.';
  end if;

  select cm1.conversation_id into existing_conversation
  from public.conversation_members cm1
  join public.conversation_members cm2
    on cm2.conversation_id = cm1.conversation_id
  where cm1.user_id = caller and cm2.user_id = other_user
    and (
      select count(*) from public.conversation_members cm3
      where cm3.conversation_id = cm1.conversation_id
    ) = 2
  limit 1;

  if existing_conversation is not null then
    return existing_conversation;
  end if;

  insert into public.conversations default values returning id into new_conversation;
  insert into public.conversation_members (conversation_id, user_id)
    values (new_conversation, caller), (new_conversation, other_user);
  return new_conversation;
end;
$$;

revoke all on function public.start_conversation(text) from public;
grant execute on function public.start_conversation(text) to authenticated;

grant select on public.profiles to authenticated;
grant update (display_name) on public.profiles to authenticated;
grant select on public.conversations to authenticated;
grant select on public.conversation_members to authenticated;
grant select, insert on public.messages to authenticated;
grant usage on schema public to authenticated;

-- Enable realtime events for messages. If already present, ignore the duplicate.
do $$
begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then
  null;
when undefined_object then
  raise notice 'supabase_realtime publication not found; enable Realtime for public.messages in Supabase dashboard.';
end $$;
